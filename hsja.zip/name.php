                
                <div class="container d-flex justify-content-start py-2" id="home_sec" style="background:white; border-radius:6px;">
                    <span><h2>Shashank Kumar</h2><span>
                    <div class="col-sm-12 py-2">
                        <span class="deco_span my-3">Web Developer</span>
                        <div class="d-flex justify-content-start">
                            <div class="p-2 bd-highlight">
                                <a href="https://www.facebook.com/shashank.kumar.9279/" target="_blank">
                                    <h1><i class="fa fa-facebook-official" aria-hidden="true"></i><h1>
                                </a>
                            </div>
                            <div class="p-2 bd-highlight">
                                <a href="https://www.linkedin.com/in/shashank-kumar-3b6252125/" target="_blank">
                                    <h1><i class="fa fa-linkedin-square" aria-hidden="true"></i><h1>
                                </a>
                            </div>
                            <div class="p-2 bd-highlight">
                                <a href="https://github.com/knightShas" target="_blank">
                                    <h1><i class="fa fa-github" aria-hidden="true"></i><h1>
                                </a>
                            </div>
                        </div>
                        <span class="deco_span my-3"><a href="email:kumarshashank45@gmail.com" target="_blank">Email Me</a></span>
                        <span class="deco_span my-3"><a href="resource/shashank cv.pdf" target="_blank">Resume</a></span>
                        <div class="d-flex justify-content-start">
                            <div class="p-2 bd-highlight">
                                <a href="https://api.whatsapp.com/send?phone=918092174112&text=Hi" target="_blank">
                                <i class="fa fa-whatsapp" aria-hidden="true"></i>&nbsp;8092174112
                                </a>
                            </div>
                            <div class="p-2 bd-highlight">
                                <a href="tel:7488088532">
                                <i class="fa fa-phone" aria-hidden="true"></i>&nbsp;7488088532
                                </a>
                            </div>
                        </div>
                        <br/>
                        <h4>Technical Skills</h4>
                        <p>
                            <span class="badge bg-warning text-dark">Html</span>
                            <span class="badge bg-warning text-dark">css</span>
                            <span class="badge bg-warning text-dark">JavaScript</span>
                            <span class="badge bg-warning text-dark">jQuery</span>
                            <span class="badge bg-warning text-dark">Python</span>
                            <span class="badge bg-warning text-dark">C</span>
                        </p>
                    </div>
                </div>
                