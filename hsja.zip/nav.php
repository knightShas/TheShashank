    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light" style="background: transparent !important;">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <ul class="navbar-nav">
                        <li class="nav-item mx-2">
                            <h4><b><a class="nav-link active" aria-current="page"href="index.php">Home</a></b></h4>
                        </li>
                        <li class="nav-item mx-2">
                            <h4><b><a class="nav-link" href="project.php">Project</a></b></h4>
                        </li>
                        <li class="nav-item mx-2">
                            <h4><b><a class="nav-link" href="#contact">Contact</a></b></h4>
                        </li>
                        <li class="nav-item mx-2">
                            <h4><b><a class="nav-link" href="#">📰 News</a></b></h4>
                        </li>
                    </ul>
                </div>
                </div>
            </div>
        </nav>
    </div>